import mongoose from 'mongoose';

const videoProgressSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  videoId: {
    type: String,
    ref: 'Video',
    required: true
  },
  watchedSeconds: {
    type: Number,
    default: 0
  },
  completed: {
    type: Boolean,
    default: false
  },
  lastWatched: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('VideoProgress', videoProgressSchema);